//
//  MTVChannel.m
//  TVTestCore
//
//  Created by Admin on 23.05.12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "MTVChannel.h"
#import "MTVShow.h"


@implementation MTVChannel

@dynamic pDateLoad;
@dynamic pID;
@dynamic pLoaded;
@dynamic pLogoUrl;
@dynamic pName;
@dynamic pProgramUrl;
@dynamic pSelected;
@dynamic sectionIdentifier;
@dynamic rTVShow;


-(void)awakeFromFetch
{
    [super awakeFromFetch];
    NSLog(@" load %@ obj",self.pName);
}

-(NSString*)sectionIdentifier 
{
    NSString *str = [self.pName substringToIndex:1]; //self.pName;
    return str; 
}


@end
