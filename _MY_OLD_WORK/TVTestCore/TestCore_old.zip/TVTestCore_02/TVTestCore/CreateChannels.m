//
//  CreateChannels.m
//  TVTestCore
//
//  Created by Admin on 18.05.12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "CreateChannels.h"
#import "MTVChannel.h"
#import "MTVShow.h"

@implementation CreateChannels
@synthesize managedObjectContext = __managedObjectContext;          //zs
@synthesize persistentStoreCoordinator = __persistentStoreCoordinator; //zs

- (id)init
{
    self = [super init];
    if (self) {
    }
    return self;
}

- (NSString*)pathDocDir 
{ 
    NSString *sandboxPath = NSHomeDirectory(); //full sandbox path 
    NSString *documentPath = [sandboxPath stringByAppendingPathComponent:@"Documents"]; 
    return documentPath;     
}


- (NSString *)pathInDocDir:(NSString*)fileName 
{ 
    NSString *sandboxPath = NSHomeDirectory(); //full sandbox path 
    NSString *documentPath = [sandboxPath stringByAppendingPathComponent:@"Documents"]; 
    return [documentPath stringByAppendingPathComponent:fileName];     
}


//========================thumbnailFromImage===================================
#pragma mark Image's methods
+ (UIImage *)thumbnailFromImage:(UIImage *)imageFrom forSize:(float)sz Radius:(float)radius
{
    float mx = sz;
    float my = sz;
    float x = imageFrom.size.width;
    float y = imageFrom.size.height;
    float d = x / y;
    if (d >= 1) {
        my = my / d;
    } else {
        mx = mx * d;
    }    
    CGRect imageRect = CGRectMake(0, 0, roundf(mx),roundf(my)); 
    UIGraphicsBeginImageContext(imageRect.size);    
    
    if (radius > 0.0) {
        UIBezierPath *bez = [UIBezierPath bezierPathWithRoundedRect:imageRect cornerRadius:radius];
        [bez addClip];
    }
    
    // Render the big image onto the image context 
    [imageFrom drawInRect:imageRect];    
    // Make a new one from the image contextpickerCell_.cellImage.image    
    UIImage *imgTo = UIGraphicsGetImageFromCurrentImageContext();
    
    //  NSData *data1 = UIImageJPEGRepresentation(imageFrom, 0.75);
    //  NSData *data2 = UIImageJPEGRepresentation(imgTo, 0.75);
    //    NSData *data1 = UIImagePNGRepresentation(imageFrom);
    //    NSData *data2 = UIImagePNGRepresentation(imgTo);    
    //    int i1 = data1.length;
    //    int i2 = data2.length;
    //    NSLog(@" image from %d to %d",i1,i2);
    
    // Clean up image context resources 
    UIGraphicsEndImageContext();    
    return imgTo;
}


- (MTVShow*)addShowFor:(MTVChannel *)channel
{
    //    static int idd = 1000;
    static int sc = 1;
    MTVShow *newManagedObject = [NSEntityDescription insertNewObjectForEntityForName:@"MTVShow"  
                                                              inManagedObjectContext:self.managedObjectContext];    
    newManagedObject.pCategory = (sc++ % 5) + 1; 
    newManagedObject.pDescription = @" will show something";
    newManagedObject.pTitle = @"any show";    

    NSDate *dat1 = [NSDate dateWithTimeIntervalSince1970:1336966875];
    newManagedObject.pStart = dat1;  
    
    NSDate *dat2 = [NSDate dateWithTimeIntervalSince1970:1336966875+300];
    newManagedObject.pStop = dat2;  
       
    newManagedObject.rTVChannel = channel;
    
    //    NSLog(@" >> (%@) for %d days",newManagedObject.pName,[arr count]); 
    //    NSLog(@"(%@)",sarr);
    return newManagedObject;
}


- (void)addChannel:(NSDictionary*)dic
{
    //    static int idd = 1000;
    MTVChannel *newManagedObject = [NSEntityDescription insertNewObjectForEntityForName:@"MTVChannel"  
                                                                 inManagedObjectContext:self.managedObjectContext];    
    newManagedObject.pLoaded = YES; 
    newManagedObject.pSelected = NO;
    newManagedObject.pID = [[dic objectForKey:@"id"] intValue];    
    newManagedObject.pName = [dic objectForKey:@"name"];  
    
    NSInteger val = [[dic objectForKey:@"updated"] intValue];
    NSDate *dat = [NSDate dateWithTimeIntervalSince1970:val];
    newManagedObject.pDateLoad = dat;  
    
    NSArray *arr = [dic objectForKey:@"url"];
    NSString *sarr = [arr componentsJoinedByString:@"&&"];
    newManagedObject.pProgramUrl = sarr;
    
    newManagedObject.pLogoUrl =  [dic objectForKey:@"logo"]; 
    
    NSMutableArray *marr = [[NSMutableArray alloc] init];
    for (int i=1; i<=10; i++) {
        MTVShow *show = [self addShowFor:newManagedObject];
//        [newManagedObject.mTvShow setByAddingObject:show];
        [marr addObject:show];
    }
    NSSet *set = [[NSSet alloc] initWithArray:marr];
    newManagedObject.rTVShow = set;    
    
    //    NSLog(@" >> (%@) for %d days",newManagedObject.pName,[arr count]); 
    //    NSLog(@"(%@)",sarr);
}


- (NSArray*)requestForEntity:(NSString*)entity Context:(NSManagedObjectContext*)context;
{
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    request.entity = [NSEntityDescription entityForName:entity inManagedObjectContext:context];
    NSError *err=nil;
    NSArray *res = [self.managedObjectContext executeFetchRequest:request error:&err];
    if (err) {
        NSLog(@"ERROR"); return nil;
    };
//    NSMutableArray *result = [[NSMutableArray alloc] initWithArray:res];
    NSLog(@" request for (%@) =%d",entity,[res count]);
    return res;
}



- (void) deleteAllObjects: (NSString *) entityDescription  {
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:entityDescription inManagedObjectContext:__managedObjectContext];
    [fetchRequest setEntity:entity];
    
    NSError *error;
    NSArray *items = [__managedObjectContext executeFetchRequest:fetchRequest error:&error];
    
    int sc=0;
    for (NSManagedObject *managedObject in items) {
        NSLog(@"%@ object deleted",entityDescription);
        [__managedObjectContext deleteObject:managedObject];
        sc++;
    }
    if (![__managedObjectContext save:&error]) {
        NSLog(@"Error deleting %@ - error:%@",entityDescription,error);
    }
    NSLog(@" !!! %d  object deleted in (%@ )",sc,entityDescription);
    
}

- (void)eraseData
{
        //Erase the persistent store from coordinator and also file manager.
    NSPersistentStore *store = [self.persistentStoreCoordinator.persistentStores lastObject];
    NSError *error = nil;
    NSURL *storeURL = store.URL;
    [self.persistentStoreCoordinator removePersistentStore:store error:&error];
    [[NSFileManager defaultManager] removeItemAtURL:storeURL error:&error];
        
        
    NSLog(@">>Data Reset");
        
    //Make new persistent store for future saves   (Taken From Above Answer)
    if (![self.persistentStoreCoordinator addPersistentStoreWithType:NSSQLiteStoreType configuration:nil URL:storeURL options:nil error:&error]) {
            // do something with the error
        NSLog(@"Error deleting :%@",error);
    }        
}

- (void)dataSave 
{
    NSError *error;
    if ([self.managedObjectContext hasChanges] && ![self.managedObjectContext save:&error])
    {
        NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
        abort();
    }     
}

- (void)parseFile:(NSString*)file 
{
    NSString *filePath = [self pathInDocDir:@"index.json"];
    BOOL exist = [[NSFileManager defaultManager] fileExistsAtPath:filePath];
    if (!exist)
        return;
    
    NSError *err;
    NSData *dat = [[NSData alloc] initWithContentsOfFile:filePath];
    NSArray *data = [NSJSONSerialization JSONObjectWithData:dat options:kNilOptions error:&err];        
    NSLog(@" parsed %d records",[data count]); 
    
    NSArray *arr1 = [self requestForEntity:@"MTVChannel" Context:self.managedObjectContext];
    NSArray *arr2 = [self requestForEntity:@"MTVShow" Context:self.managedObjectContext];
    [self dataSave];
    
    [self deleteAllObjects:@"MTVChannel"];
    [self dataSave];
    
//    [self eraseData];
    
    NSArray *arr3 = [self requestForEntity:@"MTVChannel" Context:self.managedObjectContext];
    NSArray *arr4 = [self requestForEntity:@"MTVShow" Context:self.managedObjectContext];
        
    for (NSDictionary *dic in data) {
        [self addChannel:dic];
    }

    [self dataSave];
    
//    NSError *error;
//    if ([self.managedObjectContext hasChanges] && ![self.managedObjectContext save:&error])
//    {
//        /*
//         Replace this implementation with code to handle the error appropriately.
//         
//         abort() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development. 
//         */
//        NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
//        abort();
//    } 
    
    
}


@end


//-(void)awakeFromFetch
//{
//    [super awakeFromFetch];
//    NSLog(@" load %@ obj",self.pName);
//}


//-(void)awakeFromFetch
//{
//    [super awakeFromFetch];
//    NSLog(@" load %@ obj",self.pName);
//}
//-(NSString*)sectionIdentifier 
//{
//    NSString *str = self.pName;
//    return str; 
//}

