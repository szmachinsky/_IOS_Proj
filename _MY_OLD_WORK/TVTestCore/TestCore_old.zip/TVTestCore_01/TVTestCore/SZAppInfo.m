//
//  AppInfo.m
//  TVTestCore
//
//  Created by Admin on 18.05.12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "SZAppInfo.h"
#import "SZCoreManager.h"

static SZAppInfo *_sharedAppInfo=nil;

@implementation SZAppInfo

- (id)init
{
    self = [super init];
    if (self) {
    }
    return self;
}


+ (SZAppInfo*)shared
{// static AppInfo *_sharedAppInfo=nil;
    @synchronized(self) {
        if(_sharedAppInfo == nil) {
            NSLog(@"-initialize_Shared- AppInfo");
            _sharedAppInfo = [[SZAppInfo alloc] init];
        }
    }    
    return _sharedAppInfo;    
}


+ (void)initialize
{
    NSLog(@"-initialize_Initialize- AppInfo");
    if(_sharedAppInfo == nil) {
        _sharedAppInfo = [[SZAppInfo alloc] init];
    }    
}


-(SZCoreManager*)createCoreManagerWithDataFile:(NSString*)file Model:(NSString*)model 
{
    if (!coreManager_) {
        coreManager_ = [[SZCoreManager alloc] initWithFile:file Model:model];
    }
    return coreManager_;
}



@end


