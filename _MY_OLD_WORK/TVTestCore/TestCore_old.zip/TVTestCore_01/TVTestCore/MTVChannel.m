//
//  MTVChannel.m
//  TVTestCore
//
//  Created by Admin on 22.05.12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "MTVChannel.h"
#import "MTVShow.h"


@implementation MTVChannel

@dynamic pDateLoad;
@dynamic pID;
@dynamic pLoaded;
@dynamic pLogoUrl;
@dynamic pName;
@dynamic pProgramUrl;
@dynamic pSelected;
@dynamic rTVShow;


-(void)awakeFromFetch
{
    [super awakeFromFetch];
    NSLog(@" load %@ obj",self.pName);
}


@end
