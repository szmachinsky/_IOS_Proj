//
//  MTVChannel.h
//  TVTestCore
//
//  Created by Admin on 22.05.12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class MTVShow;

@interface MTVChannel : NSManagedObject

@property (nonatomic, retain) NSDate *pDateLoad;
@property (nonatomic) NSInteger pID;
@property (nonatomic) BOOL pLoaded;
@property (nonatomic, retain) NSString * pLogoUrl;
@property (nonatomic, retain) NSString * pName;
@property (nonatomic, retain) NSString * pProgramUrl;
@property (nonatomic) BOOL pSelected;
@property (nonatomic, retain) NSSet *rTVShow;
@end

@interface MTVChannel (CoreDataGeneratedAccessors)

- (void)addRTVShowObject:(MTVShow *)value;
- (void)removeRTVShowObject:(MTVShow *)value;
- (void)addRTVShow:(NSSet *)values;
- (void)removeRTVShow:(NSSet *)values;

@end
