//
//  MTVShow.m
//  TVTestCore
//
//  Created by Admin on 22.05.12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "MTVShow.h"
#import "MTVChannel.h"


@implementation MTVShow

@dynamic pCategory;
@dynamic pDescription;
@dynamic pStart;
@dynamic pStop;
@dynamic pTitle;
@dynamic rTVChannel;

@end
